Hit the start button to start the game

when you start, a small circle and some text saying "Camera:Off" will appear, as the main camera sits in a fishtank. 

Click on the circle to expand the menu options available to the player. "fish" will open a menu for placing fish. "prop" will open a menu for placing props. 
"res" will reset the scene. "exit" will quit the game to menu.

In order to move the camera, click the text saying "Camera:Off", and then left click and drag to move the camera around.

To spawn a fish, click on the fish you wish to spawn through the fish menu.
To spawn a prop, open the prop menu to select the prop you want, then click on the base of the fish tank to place a prop there.

Fish play music as they come into the scene, and props modify that music in some way.
there are currently 2 fish and 1 placeholder prop.
We intend to have 10+ fish and 5+ props, each with unique music and effects.