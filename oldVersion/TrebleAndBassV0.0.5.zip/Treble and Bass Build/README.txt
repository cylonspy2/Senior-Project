Hit the start button to start the game

when you start, a menu and some arrows will slide into view, as the main camera stares at a fishtank. 

to spawn fish or props into the fishtank, open the add fish menu. use the sliding bar to scroll and use the props menu.
there is a reset button to reset the scene, along with quit.

there are arrows at the bottom left you can press to rotate the camera around the tank. be warned, camera verticle controls are inverted for some ungodly reason.
as you spawn fish, music will play depending on the fish. Modification of the song is not currently possible, sorry.
clicking on the button for the one available prop will drop a cube into the fishtank. it does nothing currently, sorry.